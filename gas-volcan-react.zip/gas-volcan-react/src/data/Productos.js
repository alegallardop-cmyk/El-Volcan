import img5kg from '../assets/img/galonde5.png'
import img11kg from '../assets/img/galonde11.png'
import img15kg from '../assets/img/galonde15.png'
import imgGenerica from '../assets/img/cilindro-generico.svg'

export const imagenGenerica = imgGenerica

export const productosIniciales = [
  {
    id: 1,
    imagen: img5kg,
    titulo: 'Cilindro de gas 5 kg',
    descripcion: 'Ideal para cocinas pequeñas o calefont.',
    detalle: 'Recarga de cilindro de 5 kg, ideal para cocinas pequeñas o calefont.',
    precio: 9990,
    peso: '5 kg de gas licuado',
    uso: 'Cocinas pequeñas y calefont de bajo consumo.',
    categoria: 'Residencial',
  },
  {
    id: 2,
    imagen: img11kg,
    titulo: 'Cilindro de gas 11 kg',
    descripcion: 'El más pedido por las familias.',
    detalle: 'Recarga de cilindro de 11 kg, el más pedido por las familias.',
    precio: 16990,
    peso: '11 kg de gas licuado',
    uso: 'Cocinas de 3 a 4 platos, calefont y estufas.',
    categoria: 'Residencial',
  },
  {
    id: 3,
    imagen: img15kg,
    titulo: 'Cilindro de gas 15 kg',
    descripcion: 'Para casas grandes o locales comerciales.',
    detalle: 'Recarga de cilindro de 15 kg, para casas grandes o locales comerciales.',
    precio: 21990,
    peso: '15 kg de gas licuado',
    uso: 'Casas grandes, locales comerciales y uso intensivo.',
    categoria: 'Comercial',
  },
]

export const categorias = ['Todas', 'Residencial', 'Comercial']
