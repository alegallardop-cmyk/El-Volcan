export const usuarios = [
  {
    correo: 'admin@volcan.cl',
    clave: 'admin2026',
    nombre: 'Administradora',
    apellido: 'El Volcán',
    telefono: '912345678',
    direccion: 'Av. Libertad 123',
    comuna: 'Chillán',
    tipoCliente: 'Comercial',
  },
]

export const comunas = ['Chillán', 'Chillán Viejo', 'San Carlos', 'Bulnes', 'Pinto', 'Coihueco', 'San Ignacio']
