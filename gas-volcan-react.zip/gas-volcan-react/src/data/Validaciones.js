const soloLetras = /^[A-Za-záéíóúÁÉÍÓÚñÑ\s]+$/
const formatoCorreo = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
const formatoTelefono = /^9\d{8}$/

export function formatearPrecio(numero) {
  return '$' + Number(numero).toLocaleString('es-CL')
}

export function calcularEdad(fecha) {
  const hoy = new Date()
  const nacimiento = new Date(fecha)
  let edad = hoy.getFullYear() - nacimiento.getFullYear()
  const mes = hoy.getMonth() - nacimiento.getMonth()
  if (mes < 0 || (mes === 0 && hoy.getDate() < nacimiento.getDate())) {
    edad--
  }
  return edad
}

export function validarLogin(datos) {
  const errores = {}
  if (!formatoCorreo.test(datos.correo)) errores.correo = 'El correo no tiene un formato válido'
  if (datos.clave.length < 8) errores.clave = 'La contraseña debe tener al menos 8 caracteres'
  return errores
}

export function validarRegistro(datos) {
  const errores = {}
  if (!soloLetras.test(datos.nombre)) errores.nombre = 'El nombre debe contener solo letras'
  if (!soloLetras.test(datos.apellido)) errores.apellido = 'El apellido debe contener solo letras'
  if (!formatoCorreo.test(datos.correo)) errores.correo = 'El correo no tiene un formato válido'
  if (!formatoTelefono.test(datos.telefono)) errores.telefono = 'El teléfono debe tener 9 dígitos y empezar con 9'
  if (datos.direccion.trim().length < 5) errores.direccion = 'Ingrese una dirección de despacho válida'
  if (datos.comuna === '') errores.comuna = 'Seleccione su comuna'
  if (!datos.fecnac) errores.fecnac = 'Debe ingresar su fecha de nacimiento'
  else if (calcularEdad(datos.fecnac) < 18) errores.fecnac = 'Debes ser mayor de 18 años para registrarte'
  if (datos.clave.length < 8) errores.clave = 'La contraseña debe tener al menos 8 caracteres'
  if (datos.clave !== datos.confirmarClave) errores.confirmarClave = 'Las contraseñas no coinciden'
  return errores
}

export function validarProducto(datos) {
  const errores = {}
  if (datos.titulo.trim().length < 3) errores.titulo = 'El nombre debe tener al menos 3 caracteres'
  if (!(Number(datos.kilos) > 0)) errores.kilos = 'Los kilos deben ser mayores a 0'
  if (!(Number(datos.precio) > 0)) errores.precio = 'El precio debe ser mayor a 0'
  if (datos.descripcion.trim().length < 10) errores.descripcion = 'La descripción debe tener al menos 10 caracteres'
  return errores
}

export function validarCheckout(datos) {
  const errores = {}
  if (!soloLetras.test(datos.nombre)) errores.nombre = 'El nombre debe contener solo letras'
  if (!formatoTelefono.test(datos.telefono)) errores.telefono = 'El teléfono debe tener 9 dígitos y empezar con 9'
  if (datos.direccion.trim().length < 5) errores.direccion = 'Ingrese una dirección de despacho válida'
  if (datos.comuna === '') errores.comuna = 'Seleccione la comuna de despacho'
  if (datos.horario === '') errores.horario = 'Seleccione un horario de entrega'
  if (datos.pago === '') errores.pago = 'Seleccione un medio de pago'
  return errores
}
