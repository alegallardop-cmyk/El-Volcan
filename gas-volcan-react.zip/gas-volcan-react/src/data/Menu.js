export const itemsMenu = [
  { href: '/', label: 'Inicio' },
  { href: '/productos', label: 'Productos' },
  { href: '/carrito', label: 'Carrito' },
  { href: '/login', label: 'Iniciar sesión' },
  { href: '/registro', label: 'Registrarse' },
  { href: '/perfil', label: 'Mi perfil' },
  { href: '/admin', label: 'Panel de control' },
]
