import { useState } from 'react'
import { Route, Routes, useNavigate } from 'react-router-dom'
import 'bootstrap/dist/css/bootstrap.min.css'
import './App.css'

import Header from './components/Header'
import Footer from './components/Footer'
import RutaPrivada from './components/RutaPrivada'

import Home from './views/Home'
import Productos from './views/Productos'
import Producto from './views/Producto'
import Login from './views/Login'
import Registro from './views/Registro'
import Admin from './views/Admin'
import Carrito from './views/Carrito'
import Perfil from './views/Perfil'
import NoEncontrado from './views/NoEncontrado'

import { productosIniciales, imagenGenerica } from './data/Productos'

function leerSesion() {
  const sesion = localStorage.getItem('usuario')
  return sesion ? JSON.parse(sesion) : null
}

function App() {
  const navigate = useNavigate()

  const [productos, setProductos] = useState(productosIniciales)
  const [carrito, setCarrito] = useState([])
  const [usuario, setUsuario] = useState(leerSesion)
  const [tema, setTema] = useState('claro')

  const cambiarTema = () => {
    setTema(tema === 'claro' ? 'oscuro' : 'claro')
  }

  const iniciarSesion = (datosUsuario) => {
    const sinClave = { ...datosUsuario }
    delete sinClave.clave
    localStorage.setItem('usuario', JSON.stringify(sinClave))
    setUsuario(sinClave)
  }

  const cerrarSesion = () => {
    localStorage.removeItem('usuario')
    setUsuario(null)
    navigate('/')
  }

  const agregarProducto = (datos) => {
    const nuevo = {
      id: Date.now(),
      imagen: imagenGenerica,
      titulo: datos.titulo,
      descripcion: datos.descripcion,
      detalle: datos.descripcion,
      precio: Number(datos.precio),
      peso: datos.kilos + ' kg de gas licuado',
      uso: datos.uso,
      categoria: datos.categoria,
    }
    setProductos([...productos, nuevo])
  }

  const agregarAlCarrito = (producto, cantidad) => {
    const existe = carrito.find((item) => item.id === producto.id)
    if (existe) {
      setCarrito(carrito.map((item) =>
        item.id === producto.id ? { ...item, cantidad: item.cantidad + cantidad } : item
      ))
    } else {
      setCarrito([...carrito, {
        id: producto.id,
        titulo: producto.titulo,
        imagen: producto.imagen,
        precio: producto.precio,
        cantidad: cantidad,
      }])
    }
  }

  const quitarDelCarrito = (id) => {
    setCarrito(carrito.filter((item) => item.id !== id))
  }

  const vaciarCarrito = () => {
    setCarrito([])
  }

  return (
    <div className={tema === 'oscuro' ? 'app tema-oscuro' : 'app'}>
      <Header usuario={usuario} cerrarSesion={cerrarSesion} tema={tema} cambiarTema={cambiarTema} />

      <main id="contenido">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/productos" element={<Productos productos={productos} />} />
          <Route path="/producto/:id" element={<Producto productos={productos} agregarAlCarrito={agregarAlCarrito} />} />
          <Route path="/login" element={<Login iniciarSesion={iniciarSesion} />} />
          <Route path="/registro" element={<Registro />} />
          <Route
            path="/carrito"
            element={<Carrito carrito={carrito} quitarDelCarrito={quitarDelCarrito} vaciarCarrito={vaciarCarrito} />}
          />
          <Route path="/perfil" element={<RutaPrivada><Perfil usuario={usuario} /></RutaPrivada>} />
          <Route path="/admin" element={<RutaPrivada><Admin agregarProducto={agregarProducto} /></RutaPrivada>} />
          <Route path="*" element={<NoEncontrado />} />
        </Routes>
      </main>

      <Footer />
    </div>
  )
}

export default App
