function FiltroCategorias({ categorias, categoriaActual, cambiarCategoria }) {
  return (
    <ul className="categorias">
      {categorias.map((cat) => (
        <li key={cat}>
          <button
            type="button"
            className={categoriaActual === cat ? 'activa' : ''}
            onClick={() => cambiarCategoria(cat)}
          >
            {cat}
          </button>
        </li>
      ))}
    </ul>
  )
}

export default FiltroCategorias
