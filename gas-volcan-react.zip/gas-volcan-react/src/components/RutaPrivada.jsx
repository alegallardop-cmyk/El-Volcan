import { Navigate } from 'react-router-dom'

function RutaPrivada({ children }) {
  const sesion = localStorage.getItem('usuario')

  if (!sesion) {
    return <Navigate to="/login" replace />
  }

  return children
}

export default RutaPrivada
