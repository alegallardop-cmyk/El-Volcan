function TarjetaInfo({ titulo, texto }) {
  return (
    <article className="tarjeta">
      <h3>{titulo}</h3>
      <p>{texto}</p>
    </article>
  )
}

export default TarjetaInfo
