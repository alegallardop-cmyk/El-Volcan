import MenuNavegacion from './MenuNavegacion'
import BotonTema from './BotonTema'
import { itemsMenu } from '../data/Menu'

function Header({ usuario, cerrarSesion, tema, cambiarTema }) {
  return (
    <header id="encabezado">
      <h1>Gas El Volcán</h1>
      <p>Distribución de gas licuado a domicilio en Chillán</p>

      <MenuNavegacion itemsMenu={itemsMenu} usuario={usuario} cerrarSesion={cerrarSesion} />
      <BotonTema tema={tema} cambiarTema={cambiarTema} />
    </header>
  )
}

export default Header
