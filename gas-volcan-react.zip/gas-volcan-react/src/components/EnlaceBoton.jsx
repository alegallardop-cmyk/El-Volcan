import { Link } from 'react-router-dom'

function EnlaceBoton({ to, children }) {
  return (
    <Link to={to} className="btn-comprar">
      {children}
    </Link>
  )
}

export default EnlaceBoton
