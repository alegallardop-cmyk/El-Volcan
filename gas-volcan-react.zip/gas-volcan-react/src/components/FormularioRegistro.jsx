import { useState } from 'react'
import Form from 'react-bootstrap/Form'
import Button from 'react-bootstrap/Button'
import { validarRegistro } from '../data/Validaciones'
import { comunas } from '../data/Usuarios'

const vacio = {
  nombre: '',
  apellido: '',
  correo: '',
  telefono: '',
  direccion: '',
  comuna: '',
  tipoCliente: 'Residencial',
  fecnac: '',
  clave: '',
  confirmarClave: '',
}

function FormularioRegistro() {
  const [datos, setDatos] = useState(vacio)
  const [errores, setErrores] = useState({})
  const [mensaje, setMensaje] = useState('')

  const cambiar = (e) => {
    setDatos({ ...datos, [e.target.name]: e.target.value })
  }

  const enviar = (e) => {
    e.preventDefault()
    const nuevosErrores = validarRegistro(datos)
    setErrores(nuevosErrores)
    if (Object.keys(nuevosErrores).length > 0) {
      setMensaje('')
      return
    }
    setMensaje('Cuenta creada correctamente, ' + datos.nombre)
    setDatos(vacio)
  }

  const limpiar = () => {
    setDatos(vacio)
    setErrores({})
    setMensaje('')
  }

  return (
    <Form noValidate onSubmit={enviar} onReset={limpiar}>
      <Form.Group className="mb-3" controlId="formNombre">
        <Form.Label>Nombre:</Form.Label>
        <Form.Control type="text" name="nombre" placeholder="Ingrese su nombre"
          value={datos.nombre} onChange={cambiar} isInvalid={!!errores.nombre} />
        <Form.Control.Feedback type="invalid">{errores.nombre}</Form.Control.Feedback>
      </Form.Group>

      <Form.Group className="mb-3" controlId="formApellido">
        <Form.Label>Apellido:</Form.Label>
        <Form.Control type="text" name="apellido" placeholder="Ingrese su apellido"
          value={datos.apellido} onChange={cambiar} isInvalid={!!errores.apellido} />
        <Form.Control.Feedback type="invalid">{errores.apellido}</Form.Control.Feedback>
      </Form.Group>

      <Form.Group className="mb-3" controlId="formCorreo">
        <Form.Label>Correo electrónico:</Form.Label>
        <Form.Control type="email" name="correo" placeholder="ejemplo@correo.com"
          value={datos.correo} onChange={cambiar} isInvalid={!!errores.correo} />
        <Form.Control.Feedback type="invalid">{errores.correo}</Form.Control.Feedback>
      </Form.Group>

      <Form.Group className="mb-3" controlId="formTelefono">
        <Form.Label>Teléfono:</Form.Label>
        <Form.Control type="tel" name="telefono" placeholder="912345678"
          value={datos.telefono} onChange={cambiar} isInvalid={!!errores.telefono} />
        <Form.Control.Feedback type="invalid">{errores.telefono}</Form.Control.Feedback>
      </Form.Group>

      <Form.Group className="mb-3" controlId="formDireccion">
        <Form.Label>Dirección de despacho:</Form.Label>
        <Form.Control type="text" name="direccion" placeholder="Calle, número, depto."
          value={datos.direccion} onChange={cambiar} isInvalid={!!errores.direccion} />
        <Form.Control.Feedback type="invalid">{errores.direccion}</Form.Control.Feedback>
      </Form.Group>

      <Form.Group className="mb-3" controlId="formComuna">
        <Form.Label>Comuna:</Form.Label>
        <Form.Select name="comuna" value={datos.comuna} onChange={cambiar} isInvalid={!!errores.comuna}>
          <option value="">Seleccione una comuna</option>
          {comunas.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </Form.Select>
        <Form.Control.Feedback type="invalid">{errores.comuna}</Form.Control.Feedback>
      </Form.Group>

      <Form.Group className="mb-3" controlId="formTipoCliente">
        <Form.Label>Tipo de cliente:</Form.Label>
        <Form.Select name="tipoCliente" value={datos.tipoCliente} onChange={cambiar}>
          <option value="Residencial">Residencial (hogar)</option>
          <option value="Comercial">Comercial (negocio)</option>
        </Form.Select>
      </Form.Group>

      <Form.Group className="mb-3" controlId="formFecnac">
        <Form.Label>Fecha de nacimiento:</Form.Label>
        <Form.Control type="date" name="fecnac"
          value={datos.fecnac} onChange={cambiar} isInvalid={!!errores.fecnac} />
        <Form.Control.Feedback type="invalid">{errores.fecnac}</Form.Control.Feedback>
      </Form.Group>

      <Form.Group className="mb-3" controlId="formClave">
        <Form.Label>Contraseña:</Form.Label>
        <Form.Control type="password" name="clave" placeholder="Mínimo 8 caracteres"
          value={datos.clave} onChange={cambiar} isInvalid={!!errores.clave} />
        <Form.Control.Feedback type="invalid">{errores.clave}</Form.Control.Feedback>
      </Form.Group>

      <Form.Group className="mb-3" controlId="formConfirmarClave">
        <Form.Label>Confirmar contraseña:</Form.Label>
        <Form.Control type="password" name="confirmarClave" placeholder="Repita su contraseña"
          value={datos.confirmarClave} onChange={cambiar} isInvalid={!!errores.confirmarClave} />
        <Form.Control.Feedback type="invalid">{errores.confirmarClave}</Form.Control.Feedback>
      </Form.Group>

      {mensaje && <p className="mensaje-exito">{mensaje}</p>}

      <Button variant="dark" type="submit" className="me-2">Crear cuenta</Button>
      <Button variant="secondary" type="reset">Limpiar</Button>
    </Form>
  )
}

export default FormularioRegistro
