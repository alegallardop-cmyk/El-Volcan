import { render, screen, fireEvent } from '@testing-library/react'
import { MemoryRouter, Routes, Route } from 'react-router-dom'

import FormularioLogin from './FormularioLogin'
import RutaPrivada from './RutaPrivada'

describe('Sesión y rutas privadas', () => {
  beforeEach(() => {
    localStorage.clear()
  })

  it('9. Login muestra un error si las credenciales no existen', () => {
    render(<FormularioLogin iniciarSesion={() => {}} />)
    fireEvent.change(screen.getByLabelText('Correo electrónico:'), { target: { value: 'nadie@volcan.cl' } })
    fireEvent.change(screen.getByLabelText('Contraseña:'), { target: { value: 'clave12345' } })

    fireEvent.click(screen.getByText('Iniciar sesión'))

    expect(screen.getByText('Correo o contraseña incorrectos')).toBeInTheDocument()
  })

  it('10. RutaPrivada redirige al login si no hay sesión en localStorage', () => {
    render(
      <MemoryRouter initialEntries={['/admin']}>
        <Routes>
          <Route path="/admin" element={<RutaPrivada><p>Panel de control</p></RutaPrivada>} />
          <Route path="/login" element={<p>Pantalla de login</p>} />
        </Routes>
      </MemoryRouter>
    )

    expect(screen.getByText('Pantalla de login')).toBeInTheDocument()
    expect(screen.queryByText('Panel de control')).not.toBeInTheDocument()
  })
})
