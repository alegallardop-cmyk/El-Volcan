import { useState } from 'react'
import Form from 'react-bootstrap/Form'
import Button from 'react-bootstrap/Button'
import { validarCheckout } from '../data/Validaciones'
import { comunas } from '../data/Usuarios'

function FormularioCheckout({ confirmarPedido }) {
  const [datos, setDatos] = useState({
    nombre: '',
    telefono: '',
    direccion: '',
    comuna: '',
    horario: '',
    pago: '',
  })
  const [errores, setErrores] = useState({})

  const cambiar = (e) => {
    setDatos({ ...datos, [e.target.name]: e.target.value })
  }

  const enviar = (e) => {
    e.preventDefault()
    const nuevosErrores = validarCheckout(datos)
    setErrores(nuevosErrores)
    if (Object.keys(nuevosErrores).length > 0) return
    confirmarPedido()
  }

  return (
    <Form noValidate onSubmit={enviar}>
      <Form.Group className="mb-3" controlId="formNombreDespacho">
        <Form.Label>Nombre de quien recibe:</Form.Label>
        <Form.Control type="text" name="nombre" value={datos.nombre}
          onChange={cambiar} isInvalid={!!errores.nombre} />
        <Form.Control.Feedback type="invalid">{errores.nombre}</Form.Control.Feedback>
      </Form.Group>

      <Form.Group className="mb-3" controlId="formTelefonoDespacho">
        <Form.Label>Teléfono de contacto:</Form.Label>
        <Form.Control type="tel" name="telefono" placeholder="912345678" value={datos.telefono}
          onChange={cambiar} isInvalid={!!errores.telefono} />
        <Form.Control.Feedback type="invalid">{errores.telefono}</Form.Control.Feedback>
      </Form.Group>

      <Form.Group className="mb-3" controlId="formDireccionDespacho">
        <Form.Label>Dirección de despacho:</Form.Label>
        <Form.Control type="text" name="direccion" value={datos.direccion}
          onChange={cambiar} isInvalid={!!errores.direccion} />
        <Form.Control.Feedback type="invalid">{errores.direccion}</Form.Control.Feedback>
      </Form.Group>

      <Form.Group className="mb-3" controlId="formComunaDespacho">
        <Form.Label>Comuna:</Form.Label>
        <Form.Select name="comuna" value={datos.comuna} onChange={cambiar} isInvalid={!!errores.comuna}>
          <option value="">Seleccione una comuna</option>
          {comunas.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </Form.Select>
        <Form.Control.Feedback type="invalid">{errores.comuna}</Form.Control.Feedback>
      </Form.Group>

      <Form.Group className="mb-3" controlId="formHorario">
        <Form.Label>Horario de entrega:</Form.Label>
        <Form.Select name="horario" value={datos.horario} onChange={cambiar} isInvalid={!!errores.horario}>
          <option value="">Seleccione un horario</option>
          <option value="Mañana (9:00 a 13:00)">Mañana (9:00 a 13:00)</option>
          <option value="Tarde (14:00 a 19:00)">Tarde (14:00 a 19:00)</option>
        </Form.Select>
        <Form.Control.Feedback type="invalid">{errores.horario}</Form.Control.Feedback>
      </Form.Group>

      <Form.Group className="mb-3" controlId="formPago">
        <Form.Label>Medio de pago:</Form.Label>
        <Form.Select name="pago" value={datos.pago} onChange={cambiar} isInvalid={!!errores.pago}>
          <option value="">Seleccione un medio de pago</option>
          <option value="Efectivo al recibir">Efectivo al recibir</option>
          <option value="Transferencia">Transferencia</option>
          <option value="Tarjeta al recibir">Tarjeta al recibir</option>
        </Form.Select>
        <Form.Control.Feedback type="invalid">{errores.pago}</Form.Control.Feedback>
      </Form.Group>

      <Button variant="dark" type="submit">Confirmar pedido</Button>
    </Form>
  )
}

export default FormularioCheckout
