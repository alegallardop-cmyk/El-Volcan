function BotonTema({ tema, cambiarTema }) {
  return (
    <button type="button" className="btn-tema" onClick={cambiarTema}>
      {tema === 'claro' ? '🌙 Modo oscuro' : '☀️ Modo claro'}
    </button>
  )
}

export default BotonTema
