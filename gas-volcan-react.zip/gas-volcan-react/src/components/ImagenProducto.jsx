function ImagenProducto({ imagen, titulo }) {
  return (
    <div className="espacio-imagen">
      <img src={imagen} alt={titulo} />
    </div>
  )
}

export default ImagenProducto
