import { useState } from 'react'
import Form from 'react-bootstrap/Form'
import Button from 'react-bootstrap/Button'
import { validarProducto } from '../data/Validaciones'

const vacio = {
  titulo: '',
  kilos: '',
  precio: '',
  categoria: 'Residencial',
  descripcion: '',
  uso: '',
}

function FormularioProducto({ agregarProducto }) {
  const [datos, setDatos] = useState(vacio)
  const [errores, setErrores] = useState({})

  const cambiar = (e) => {
    setDatos({ ...datos, [e.target.name]: e.target.value })
  }

  const enviar = (e) => {
    e.preventDefault()
    const nuevosErrores = validarProducto(datos)
    setErrores(nuevosErrores)
    if (Object.keys(nuevosErrores).length > 0) return
    agregarProducto(datos)
    setDatos(vacio)
  }

  return (
    <Form noValidate onSubmit={enviar}>
      <Form.Group className="mb-3" controlId="formTitulo">
        <Form.Label>Nombre del producto:</Form.Label>
        <Form.Control type="text" name="titulo" placeholder="Ej: Cilindro de gas 45 kg"
          value={datos.titulo} onChange={cambiar} isInvalid={!!errores.titulo} />
        <Form.Control.Feedback type="invalid">{errores.titulo}</Form.Control.Feedback>
      </Form.Group>

      <Form.Group className="mb-3" controlId="formKilos">
        <Form.Label>Kilos de gas:</Form.Label>
        <Form.Control type="number" name="kilos" placeholder="Ej: 45"
          value={datos.kilos} onChange={cambiar} isInvalid={!!errores.kilos} />
        <Form.Control.Feedback type="invalid">{errores.kilos}</Form.Control.Feedback>
      </Form.Group>

      <Form.Group className="mb-3" controlId="formPrecio">
        <Form.Label>Precio (CLP):</Form.Label>
        <Form.Control type="number" name="precio" placeholder="Ej: 59990"
          value={datos.precio} onChange={cambiar} isInvalid={!!errores.precio} />
        <Form.Control.Feedback type="invalid">{errores.precio}</Form.Control.Feedback>
      </Form.Group>

      <Form.Group className="mb-3" controlId="formCategoria">
        <Form.Label>Categoría:</Form.Label>
        <Form.Select name="categoria" value={datos.categoria} onChange={cambiar}>
          <option value="Residencial">Residencial</option>
          <option value="Comercial">Comercial</option>
        </Form.Select>
      </Form.Group>

      <Form.Group className="mb-3" controlId="formDescripcion">
        <Form.Label>Descripción:</Form.Label>
        <Form.Control as="textarea" rows={2} name="descripcion" placeholder="Descripción breve del producto"
          value={datos.descripcion} onChange={cambiar} isInvalid={!!errores.descripcion} />
        <Form.Control.Feedback type="invalid">{errores.descripcion}</Form.Control.Feedback>
      </Form.Group>

      <Form.Group className="mb-3" controlId="formUso">
        <Form.Label>Uso recomendado:</Form.Label>
        <Form.Control type="text" name="uso" placeholder="Ej: Restaurantes y calderas"
          value={datos.uso} onChange={cambiar} />
      </Form.Group>

      <Button variant="dark" type="submit">Agregar producto</Button>
    </Form>
  )
}

export default FormularioProducto
