import ItemCarrito from './ItemCarrito'
import { formatearPrecio } from '../data/Validaciones'

function ResumenCarrito({ carrito, quitarDelCarrito }) {
  const total = carrito.reduce((suma, item) => suma + item.precio * item.cantidad, 0)

  return (
    <div>
      {carrito.map((item) => (
        <ItemCarrito key={item.id} item={item} quitarDelCarrito={quitarDelCarrito} />
      ))}
      <p className="total-carrito">
        Total a pagar: <strong>{formatearPrecio(total)}</strong>
      </p>
    </div>
  )
}

export default ResumenCarrito
