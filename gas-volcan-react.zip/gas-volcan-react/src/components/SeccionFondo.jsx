function SeccionFondo({ id, titulo, texto, video, imagen }) {
  return (
    <section id={id} className="seccion seccion-fondo">
      {video && (
        <video className="medio-fondo" autoPlay loop muted playsInline>
          <source src={video} type="video/mp4" />
          Tu navegador no soporta el video.
        </video>
      )}
      {imagen && <img className="medio-fondo" src={imagen} alt={titulo} />}

      <div className="fondo-overlay">
        <h2>{titulo}</h2>
        <p>{texto}</p>
      </div>
    </section>
  )
}

export default SeccionFondo
