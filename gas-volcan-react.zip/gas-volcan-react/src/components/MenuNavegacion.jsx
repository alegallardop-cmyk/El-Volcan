import { NavLink } from 'react-router-dom'

function MenuNavegacion({ itemsMenu, usuario, cerrarSesion }) {
  return (
    <nav id="menu-principal">
      <ul>
        {itemsMenu.map((item) => (
          <li key={item.href}>
            <NavLink
              to={item.href}
              end
              className={({ isActive }) => (isActive ? 'activo' : '')}
            >
              {item.label}
            </NavLink>
          </li>
        ))}

        {usuario !== null && (
          <li>
            <button type="button" className="btn-salir" onClick={cerrarSesion}>
              Cerrar sesión
            </button>
          </li>
        )}
      </ul>
    </nav>
  )
}

export default MenuNavegacion
