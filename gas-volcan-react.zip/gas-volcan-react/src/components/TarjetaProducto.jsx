import ImagenProducto from './ImagenProducto'
import Precio from './Precio'
import EnlaceBoton from './EnlaceBoton'
import BotonFavorito from './BotonFavorito'

function TarjetaProducto({ id, imagen, titulo, descripcion, precio }) {
  return (
    <article className="tarjeta">
      <ImagenProducto imagen={imagen} titulo={titulo} />
      <h3>{titulo}</h3>
      <p>{descripcion}</p>
      <Precio valor={precio} />
      <EnlaceBoton to={`/producto/${id}`}>Ver detalle</EnlaceBoton>
      <BotonFavorito />
    </article>
  )
}

export default TarjetaProducto
