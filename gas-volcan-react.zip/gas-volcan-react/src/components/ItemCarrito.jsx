import { formatearPrecio } from '../data/Validaciones'

function ItemCarrito({ item, quitarDelCarrito }) {
  return (
    <div className="item-carrito">
      <img src={item.imagen} alt={item.titulo} />
      <div className="item-info">
        <h3>{item.titulo}</h3>
        <p>Cantidad: {item.cantidad}</p>
      </div>

      <p className="item-subtotal">{formatearPrecio(item.precio * item.cantidad)}</p>

      <button type="button" className="btn-quitar" onClick={() => quitarDelCarrito(item.id)}>
        Quitar
      </button>
    </div>
  )
}

export default ItemCarrito
