import { formatearPrecio } from '../data/Validaciones'

function Precio({ valor }) {
  return <p className="precio">{formatearPrecio(valor)}</p>
}

export default Precio
