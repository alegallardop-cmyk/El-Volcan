import { render, screen, fireEvent } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'

import TarjetaProducto from './TarjetaProducto'
import BotonFavorito from './BotonFavorito'
import DetalleProducto from './DetalleProducto'
import Productos from '../views/Productos'
import { productosIniciales } from '../data/Productos'

const productoMock = productosIniciales[1]

describe('Componentes del catálogo', () => {
  it('5. TarjetaProducto muestra el nombre y el precio con formato', () => {
    render(
      <MemoryRouter>
        <TarjetaProducto {...productoMock} />
      </MemoryRouter>
    )

    expect(screen.getByText('Cilindro de gas 11 kg')).toBeInTheDocument()
    expect(screen.getByText('$16.990')).toBeInTheDocument()
  })

  it('6. BotonFavorito cambia a "★ Favorito" al hacer click', () => {
    render(<BotonFavorito />)
    const boton = screen.getByRole('button')

    fireEvent.click(boton)

    expect(boton).toHaveTextContent('★ Favorito')
  })

  it('7. El filtro "Comercial" muestra solo el cilindro de 15 kg', () => {
    render(
      <MemoryRouter>
        <Productos productos={productosIniciales} />
      </MemoryRouter>
    )

    fireEvent.click(screen.getByText('Comercial'))

    const titulos = screen.getAllByRole('heading', { level: 3 })
    expect(titulos.length).toBe(1)
    expect(titulos[0]).toHaveTextContent('Cilindro de gas 15 kg')
  })

  it('8. DetalleProducto calcula el total según la cantidad', () => {
    render(<DetalleProducto producto={productoMock} agregarAlCarrito={() => {}} />)

    fireEvent.change(screen.getByLabelText('Cantidad:'), { target: { value: '3' } })
    fireEvent.click(screen.getByText('Calcular total'))

    expect(screen.getByText('Total: $50.970')).toBeInTheDocument()
  })
})
