function Footer() {
  return (
    <footer id="pie">
      <p>
        <small>&copy; 2026 Gas El Volcán - Proyecto académico DSY1104</small>
      </p>
    </footer>
  )
}

export default Footer
