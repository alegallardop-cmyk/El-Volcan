import { validarLogin, validarRegistro, validarProducto } from '../data/Validaciones'

describe('Validaciones de formularios', () => {
  it('1. Login: rechaza un correo sin formato válido', () => {
    const datos = { correo: 'correo-sin-arroba', clave: 'clave1234' }

    const errores = validarLogin(datos)

    expect(errores.correo).toBe('El correo no tiene un formato válido')
  })

  it('2. Login: rechaza una contraseña de menos de 8 caracteres', () => {
    const datos = { correo: 'admin@volcan.cl', clave: '123' }

    const errores = validarLogin(datos)

    expect(errores.clave).toBe('La contraseña debe tener al menos 8 caracteres')
  })

  it('3. Registro: rechaza a un menor de 18 años y contraseñas distintas', () => {
    const datos = {
      nombre: 'Ana',
      apellido: 'Soto',
      correo: 'ana@gmail.com',
      telefono: '912345678',
      direccion: 'Los Aromos 22',
      comuna: 'Bulnes',
      fecnac: '2015-01-01',
      clave: 'claveSegura1',
      confirmarClave: 'otraClave1',
    }

    const errores = validarRegistro(datos)

    expect(errores.fecnac).toBe('Debes ser mayor de 18 años para registrarte')
    expect(errores.confirmarClave).toBe('Las contraseñas no coinciden')
  })

  it('4. Panel de control: rechaza un producto con precio 0', () => {
    const datos = { titulo: 'Cilindro 45 kg', kilos: '45', precio: '0', descripcion: 'Para restaurantes y calderas.' }

    const errores = validarProducto(datos)

    expect(errores.precio).toBe('El precio debe ser mayor a 0')
  })
})
