import { useState } from 'react'

function BotonFavorito() {
  const [meGusta, setMeGusta] = useState(false)

  const alternar = () => {
    if (meGusta === false) setMeGusta(true)
    else setMeGusta(false)
  }

  return (
    <button
      type="button"
      onClick={alternar}
      className={meGusta ? 'btn-favorito activo' : 'btn-favorito'}
    >
      {meGusta ? '★ Favorito' : '☆ Agregar a favoritos'}
    </button>
  )
}

export default BotonFavorito
