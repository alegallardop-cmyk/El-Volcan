import { useState } from 'react'
import Form from 'react-bootstrap/Form'
import Button from 'react-bootstrap/Button'
import { validarLogin } from '../data/Validaciones'
import { usuarios } from '../data/Usuarios'

const vacio = { correo: '', clave: '' }

function FormularioLogin({ iniciarSesion }) {
  const [datos, setDatos] = useState(vacio)
  const [errores, setErrores] = useState({})
  const [mensajeError, setMensajeError] = useState('')

  const cambiar = (e) => {
    setDatos({ ...datos, [e.target.name]: e.target.value })
  }

  const enviar = (e) => {
    e.preventDefault()
    setMensajeError('')

    const nuevosErrores = validarLogin(datos)
    setErrores(nuevosErrores)
    if (Object.keys(nuevosErrores).length > 0) return

    const usuario = usuarios.find((u) => u.correo === datos.correo && u.clave === datos.clave)
    if (!usuario) {
      setMensajeError('Correo o contraseña incorrectos')
      return
    }

    iniciarSesion(usuario)
  }

  const limpiar = () => {
    setDatos(vacio)
    setErrores({})
    setMensajeError('')
  }

  return (
    <Form noValidate onSubmit={enviar} onReset={limpiar}>
      <Form.Group className="mb-3" controlId="formCorreo">
        <Form.Label>Correo electrónico:</Form.Label>
        <Form.Control
          type="email"
          name="correo"
          placeholder="ejemplo@correo.com"
          value={datos.correo}
          onChange={cambiar}
          isInvalid={!!errores.correo}
        />
        <Form.Control.Feedback type="invalid">{errores.correo}</Form.Control.Feedback>
      </Form.Group>

      <Form.Group className="mb-3" controlId="formClave">
        <Form.Label>Contraseña:</Form.Label>
        <Form.Control
          type="password"
          name="clave"
          placeholder="Mínimo 8 caracteres"
          value={datos.clave}
          onChange={cambiar}
          isInvalid={!!errores.clave}
        />
        <Form.Control.Feedback type="invalid">{errores.clave}</Form.Control.Feedback>
      </Form.Group>

      {mensajeError && <p className="mensaje-error">{mensajeError}</p>}

      <Button variant="dark" type="submit" className="me-2">Iniciar sesión</Button>
      <Button variant="secondary" type="reset">Limpiar</Button>
    </Form>
  )
}

export default FormularioLogin
