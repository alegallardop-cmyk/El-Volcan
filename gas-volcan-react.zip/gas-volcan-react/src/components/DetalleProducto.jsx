import { useState } from 'react'
import Boton from './Boton'
import Precio from './Precio'
import { formatearPrecio } from '../data/Validaciones'

function DetalleProducto({ producto, agregarAlCarrito }) {
  const [cantidad, setCantidad] = useState(1)
  const [total, setTotal] = useState(0)
  const [mostrarInfo, setMostrarInfo] = useState(false)
  const [mensaje, setMensaje] = useState('')

  const calcularTotal = () => {
    setTotal(cantidad * producto.precio)
  }

  const alternarInfo = () => {
    setMostrarInfo(!mostrarInfo)
  }

  const agregar = () => {
    agregarAlCarrito(producto, Number(cantidad))
    setMensaje('Se agregaron ' + cantidad + ' unidades a tu pedido')
  }

  return (
    <div className="detalle-producto">
      <div className="detalle-imagen">
        <img src={producto.imagen} alt={producto.titulo} />
      </div>

      <div className="detalle-info">
        <h2>{producto.titulo}</h2>
        <p>{producto.detalle}</p>
        <Precio valor={producto.precio} />

        <label htmlFor="cantidad">Cantidad: </label>
        <input
          type="number"
          id="cantidad"
          min="1"
          value={cantidad}
          onChange={(e) => setCantidad(e.target.value)}
        />
        <br />
        <br />

        <Boton onClick={calcularTotal}>Calcular total</Boton>
        <p>
          Total: {formatearPrecio(total)}
        </p>

        <Boton onClick={alternarInfo}>
          {mostrarInfo ? 'Ocultar información adicional' : 'Mostrar información adicional'}
        </Boton>
        {mostrarInfo && (
          <div>
            <p><strong>Peso:</strong> {producto.peso}</p>
            <p><strong>Uso recomendado:</strong> {producto.uso}</p>
          </div>
        )}

        <br />
        <Boton onClick={agregar}>Agregar al pedido</Boton>
        {mensaje && <p className="mensaje-exito">{mensaje}</p>}
      </div>
    </div>
  )
}

export default DetalleProducto
