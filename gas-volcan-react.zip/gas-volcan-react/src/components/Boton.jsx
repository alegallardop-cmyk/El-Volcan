function Boton({ children, onClick, tipo = 'button' }) {
  return (
    <button type={tipo} className="btn-comprar" onClick={onClick}>
      {children}
    </button>
  )
}

export default Boton
