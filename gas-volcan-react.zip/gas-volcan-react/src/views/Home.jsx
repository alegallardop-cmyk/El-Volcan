import Seccion from '../components/Seccion'
import SeccionFondo from '../components/SeccionFondo'
import TarjetaInfo from '../components/TarjetaInfo'

import videoVolcan from '../assets/img/video_gas_volcan.mp4'
import imgBienvenidos from '../assets/img/Bienvenidos.png'

function Home() {
  const destacados = [
    { id: 1, titulo: 'Entrega rápida', texto: 'Despachamos el mismo día en Chillán.' },
    { id: 2, titulo: 'Cilindros revisados', texto: 'Cada envase se revisa antes de salir.' },
    { id: 3, titulo: 'Cobertura local', texto: 'Chillán y comunas cercanas.' },
  ]

  return (
    <>
      <SeccionFondo
        id="inicio"
        video={videoVolcan}
        titulo="Bienvenidos"
        texto="Distribuidora de Gas El Volcán es una empresa familiar que entrega cilindros de gas de 5, 11 y 15 kg en Chillán y comunas aledañas desde 1998."
      />

      <SeccionFondo
        id="video"
        imagen={imgBienvenidos}
        titulo="Quiénes somos"
        texto="Somos una empresa familiar de Chillán, Región de Ñuble. Repartimos cilindros de gas a clientes residenciales y comerciales, y estamos trabajando para que nuestros clientes puedan pedir gas en línea."
      />

      <Seccion id="destacados" titulo="¿Por qué elegirnos?">
        <div className="galeria">
          {destacados.map((d) => (
            <TarjetaInfo key={d.id} titulo={d.titulo} texto={d.texto} />
          ))}
        </div>
      </Seccion>
    </>
  )
}

export default Home
