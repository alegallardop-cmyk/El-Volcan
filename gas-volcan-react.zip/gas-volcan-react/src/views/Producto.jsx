import { Link, useParams } from 'react-router-dom'
import Seccion from '../components/Seccion'
import DetalleProducto from '../components/DetalleProducto'
import NoEncontrado from './NoEncontrado'

function Producto({ productos, agregarAlCarrito }) {
  const { id } = useParams()
  const producto = productos.find((p) => p.id === Number(id))

  if (!producto) return <NoEncontrado />

  return (
    <Seccion>
      <p><Link to="/productos">&larr; Volver al catálogo</Link></p>
      <DetalleProducto producto={producto} agregarAlCarrito={agregarAlCarrito} />
    </Seccion>
  )
}

export default Producto
