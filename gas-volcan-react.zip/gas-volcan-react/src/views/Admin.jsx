import Seccion from '../components/Seccion'
import FormularioProducto from '../components/FormularioProducto'

function Admin({ agregarProducto }) {
  return (
    <Seccion id="nuevo-producto" titulo="Agregar producto al catálogo">
      <FormularioProducto agregarProducto={agregarProducto} />
    </Seccion>
  )
}

export default Admin
