import Seccion from '../components/Seccion'

function Perfil({ usuario }) {
  return (
    <Seccion titulo="Mi perfil">
      <p><strong>Nombre:</strong> {usuario.nombre} {usuario.apellido}</p>
      <p><strong>Correo:</strong> {usuario.correo}</p>
      <p><strong>Teléfono:</strong> {usuario.telefono}</p>
      <p><strong>Dirección de despacho:</strong> {usuario.direccion}</p>
      <p><strong>Comuna:</strong> {usuario.comuna}</p>
      <p><strong>Tipo de cliente:</strong> {usuario.tipoCliente}</p>
    </Seccion>
  )
}

export default Perfil
