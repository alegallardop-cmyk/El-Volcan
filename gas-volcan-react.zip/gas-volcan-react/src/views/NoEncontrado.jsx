import { Link } from 'react-router-dom'
import Seccion from '../components/Seccion'

function NoEncontrado() {
  return (
    <Seccion titulo="Error 404 - Página no encontrada">
      <p>La página que buscas no existe o fue movida.</p>
      <p><Link to="/">&larr; Volver a la página principal</Link></p>
    </Seccion>
  )
}

export default NoEncontrado
