import { Link } from 'react-router-dom'
import Seccion from '../components/Seccion'
import FormularioRegistro from '../components/FormularioRegistro'

function Registro() {
  return (
    <Seccion titulo="Crear cuenta">
      <FormularioRegistro />

      <p className="mt-3">¿Ya tienes cuenta? <Link to="/login">Inicia sesión</Link></p>
      <p><Link to="/">&larr; Volver a la página principal</Link></p>
    </Seccion>
  )
}

export default Registro
