import { useState } from 'react'
import { Link } from 'react-router-dom'
import Seccion from '../components/Seccion'
import ResumenCarrito from '../components/ResumenCarrito'
import FormularioCheckout from '../components/FormularioCheckout'

function Carrito({ carrito, quitarDelCarrito, vaciarCarrito }) {
  const [pedidoConfirmado, setPedidoConfirmado] = useState(false)

  const confirmarPedido = () => {
    setPedidoConfirmado(true)
    vaciarCarrito()
  }

  if (pedidoConfirmado) {
    return (
      <Seccion titulo="Pedido recibido">
        <p className="mensaje-exito">Tu pedido fue recibido correctamente.</p>
        <p><Link to="/productos">Volver a productos</Link></p>
      </Seccion>
    )
  }

  if (carrito.length === 0) {
    return (
      <Seccion titulo="Tu carrito">
        <p>Tu carrito está vacío.</p>
        <p><Link to="/productos">Ver productos</Link></p>
      </Seccion>
    )
  }

  return (
    <>
      <Seccion titulo="Tu carrito">
        <ResumenCarrito carrito={carrito} quitarDelCarrito={quitarDelCarrito} />
      </Seccion>

      <Seccion titulo="Datos de despacho y pago">
        <FormularioCheckout confirmarPedido={confirmarPedido} />
      </Seccion>
    </>
  )
}

export default Carrito
