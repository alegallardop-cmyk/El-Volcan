import { Link, useNavigate } from 'react-router-dom'
import Seccion from '../components/Seccion'
import FormularioLogin from '../components/FormularioLogin'

function Login({ iniciarSesion }) {
  const navigate = useNavigate()

  const entrar = (usuario) => {
    iniciarSesion(usuario)
    navigate('/perfil')
  }

  return (
    <Seccion titulo="Iniciar sesión">
      <FormularioLogin iniciarSesion={entrar} />

      <p className="mt-3">¿No tienes cuenta? <Link to="/registro">Regístrate aquí</Link></p>
      <p><Link to="/">&larr; Volver a la página principal</Link></p>
    </Seccion>
  )
}

export default Login
