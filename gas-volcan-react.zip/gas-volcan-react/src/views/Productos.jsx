import { useState } from 'react'
import Seccion from '../components/Seccion'
import GaleriaProductos from '../components/GaleriaProductos'
import FiltroCategorias from '../components/FiltroCategorias'
import { categorias } from '../data/Productos'

function Productos({ productos }) {
  const [categoria, setCategoria] = useState('Todas')

  const productosVisibles =
    categoria === 'Todas' ? productos : productos.filter((p) => p.categoria === categoria)

  return (
    <Seccion id="catalogo" titulo="Nuestros productos">
      <p>Cilindros de gas licuado para tu hogar o negocio, con despacho en Chillán y alrededores.</p>

      <FiltroCategorias
        categorias={categorias}
        categoriaActual={categoria}
        cambiarCategoria={setCategoria}
      />

      <GaleriaProductos productos={productosVisibles} />
    </Seccion>
  )
}

export default Productos
